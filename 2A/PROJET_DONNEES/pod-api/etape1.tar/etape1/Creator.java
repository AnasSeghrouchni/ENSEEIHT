public class Creator {
    public static void main(String[] argv) {
        TestNRV testNRV =  new TestNRV(10);
        System.out.println("Creation ok");
}
}