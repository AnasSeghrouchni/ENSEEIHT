import java.awt.*;
import java.awt.event.*;
import java.rmi.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;
import java.rmi.registry.*;


public class Irc_unlock extends Frame {
	public TextArea		text;
	public TextField	data;
	SharedObject		sentence;
	static String		myName;

	public static void main(String argv[]) {
		
		if (argv.length != 1) {
			System.out.println("java Irc_unlock <name>");
			return;
		}
		myName = argv[0];
	
		// initialize the system
		Client.init();
		
		// look up the Irc_unlock object in the name server
		// if not found, create it, and register it in the name server
		SharedObject s = Client.lookup("Irc_unlock");
		if (s == null) {
			s = Client.create(new Sentence());
			Client.register("Irc_unlock", s);
		}
		// create the graphical part
		new Irc_unlock(s);
	}

	public Irc_unlock(SharedObject s) {
	
		setLayout(new FlowLayout());
	
		text=new TextArea(10,60);
		text.setEditable(false);
		text.setForeground(Color.red);
		add(text);
	
		data=new TextField(60);
		add(data);
	
		Button write_button = new Button("write");
		write_button.addActionListener(new writeListener_u(this));
		add(write_button);
		Button read_button = new Button("read");
		read_button.addActionListener(new readListener_u(this));
		add(read_button);
		Button unlock_button = new Button("unlock");
		unlock_button.addActionListener(new unlockListener(this));
		add(unlock_button);

		setSize(470,300);
		text.setBackground(Color.black); 
		show();
		
		sentence = s;
	}
}



class readListener_u implements ActionListener {
	Irc_unlock Irc_unlock;
	public readListener_u (Irc_unlock i) {
		Irc_unlock = i;
	}
	public void actionPerformed (ActionEvent e) {
		
		// lock the object in read mode
		Irc_unlock.sentence.lock_read();
		
		// invoke the method
		String s = ((Sentence)(Irc_unlock.sentence.obj)).read();
		
		// display the read value
		Irc_unlock.text.append(s+"\n");
	}
}

class writeListener_u implements ActionListener {
	Irc_unlock Irc_unlock;
	public writeListener_u (Irc_unlock i) {
        	Irc_unlock = i;
	}
	public void actionPerformed (ActionEvent e) {
		
		// get the value to be written from the buffer
        	String s = Irc_unlock.data.getText();
        	
    	// lock the object in write mode
		Irc_unlock.sentence.lock_write();
		
		// invoke the method
		((Sentence)(Irc_unlock.sentence.obj)).write(Irc_unlock.myName+" wrote "+s);
		Irc_unlock.data.setText("");

	}
}

class unlockListener implements ActionListener {
	Irc_unlock Irc_unlock;
	public unlockListener (Irc_unlock i) {
        	Irc_unlock = i;
	}
	public void actionPerformed (ActionEvent e) {

		// unlock the object
		Irc_unlock.sentence.unlock();
        System.out.println("J'ai unlock");
        Irc_unlock.data.setText("");
	}
}

