

    public class TestNRV {
        SharedObject[] so;
        int taille;
    
        public TestNRV(int taille) {
            this.taille = taille;
            so = new SharedObject[taille];
            Client.init();
            for (int i = 0; i < taille; i++) {
                so[i] = Client.create(new IntShared());
                Client.register("IntShared" + i, so[i]);
            }
        }
    }
    